# MinutFix.in — Static Landing Page

This is a single-file, responsive, ready-to-deploy landing page for MinutFix.in.

## What's included
- `index.html` — Single page using Tailwind CDN, responsive layout.
- Simple client-side booking form that stores submissions in browser `localStorage` (placeholder - replace with real backend endpoint).

## How to deploy
### Quick (GitHub Pages / Netlify / Vercel)
1. Create a new repository and push the files.
2. Deploy the repository on Netlify / Vercel or enable GitHub Pages.
3. That's it — the site is static and will work immediately.

### To connect a backend
- Replace the form handler in `index.html` with a `fetch()` POST to your API endpoint.
- Add server-side logic to process bookings, send SMS/OTP, and dispatch vendor notifications.

## Notes
- Replace placeholder contact email (support@minutfix.in) with your real support address.
- Add analytics, SEO meta tags, and favicons as needed.
- For production, consider building a React/Vue app with authentication & admin panel.